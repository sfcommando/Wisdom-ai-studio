# Wisdom AI Studio — PRO MVP v0.3

An Android-ready Flutter + Node backend for:
- AI chat
- AI image generation
- text/photo-to-video workflow
- credits
- My Creations gallery API
- asynchronous video jobs

## Important provider note
The video layer is isolated behind `VIDEO_PROVIDER`. The current Replicate Sora 2 route is only a development integration and should be replaced/updated before a production launch because the provider/model lifecycle is changing.

## Run backend
```bash
cd backend
npm install
cp .env.example .env
# add API keys
npm start
```

## Run Flutter
```bash
cd mobile
flutter pub get
flutter run --dart-define=BACKEND_URL=http://10.0.2.2:3000
```

For a physical Android phone, use your computer's LAN IP instead of `10.0.2.2`.

## Credits
The demo backend keeps credits server-side and deducts:
- Chat: 1 credit
- Image: 10 credits
- Video: 2 credits/second

The in-memory store is for development only. Production should use Postgres/Supabase/Firebase and durable object storage.

## Production checklist
1. Add real authentication (Supabase Auth/Firebase Auth/etc.).
2. Replace in-memory users/creations/jobs with a database.
3. Store generated media in durable object storage.
4. Add provider webhooks or polling workers for video jobs.
5. Add moderation, rate limits, abuse controls and usage quotas.
6. Add subscriptions/payment processing.
7. Put backend behind HTTPS.
8. Remove `/credits/demo-topup`.
9. Add Android signing and build an AAB for Play Store.
10. Replace the video provider implementation before launch if its API/model is being retired.

const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const crypto = require("crypto");

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({limit:"2mb"}));

const PORT = process.env.PORT || 3000;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const OPENAI_CHAT_MODEL = process.env.OPENAI_CHAT_MODEL || "gpt-5.6";
const OPENAI_IMAGE_MODEL = process.env.OPENAI_IMAGE_MODEL || "gpt-image-1";
const VIDEO_PROVIDER = process.env.VIDEO_PROVIDER || "replicate";
const REPLICATE_API_TOKEN = process.env.REPLICATE_API_TOKEN;

const users = new Map();       // demo store; replace with Postgres/Supabase
const creations = new Map();  // demo store; replace with durable DB + object storage
const jobs = new Map();

function getUser(req) {
  const id = req.header("x-user-id") || "demo-user";
  if (!users.has(id)) users.set(id, {id, credits: 100});
  return users.get(id);
}

function spendCredits(user, amount) {
  if (user.credits < amount) {
    const e = new Error("Not enough credits");
    e.status = 402;
    throw e;
  }
  user.credits -= amount;
}

function saveCreation(userId, item) {
  const id = crypto.randomUUID();
  const record = {id, userId, createdAt:new Date().toISOString(), ...item};
  creations.set(id, record);
  return record;
}

app.get("/health", (req,res)=>res.json({ok:true, provider:VIDEO_PROVIDER}));

app.get("/me", (req,res)=>{
  const user=getUser(req);
  res.json({id:user.id, credits:user.credits});
});

app.get("/creations", (req,res)=>{
  const user=getUser(req);
  res.json([...creations.values()].filter(x=>x.userId===user.id)
    .sort((a,b)=>b.createdAt.localeCompare(a.createdAt)));
});

app.post("/credits/demo-topup", (req,res)=>{
  // Development-only endpoint. Remove before production.
  if (process.env.NODE_ENV === "production") return res.status(404).end();
  const user=getUser(req);
  user.credits += Number(req.body?.credits || 100);
  res.json({credits:user.credits});
});

app.post("/chat", async (req,res)=>{
  try {
    if (!OPENAI_API_KEY) return res.status(500).json({error:"OPENAI_API_KEY is not configured"});
    const user=getUser(req);
    spendCredits(user, 1);
    const response = await fetch("https://api.openai.com/v1/responses", {
      method:"POST",
      headers:{"Authorization":`Bearer ${OPENAI_API_KEY}`,"Content-Type":"application/json"},
      body:JSON.stringify({
        model:OPENAI_CHAT_MODEL,
        store:false,
        input:req.body?.message || ""
      })
    });
    const data=await response.json();
    if (!response.ok) throw new Error(data?.error?.message || "OpenAI request failed");
    res.json({text:data.output_text || "", credits:user.credits});
  } catch(e) { res.status(e.status || 500).json({error:e.message}); }
});

app.post("/generate-image", async (req,res)=>{
  try {
    if (!OPENAI_API_KEY) return res.status(500).json({error:"OPENAI_API_KEY is not configured"});
    const user=getUser(req);
    spendCredits(user, 10);
    const response = await fetch("https://api.openai.com/v1/images/generations", {
      method:"POST",
      headers:{"Authorization":`Bearer ${OPENAI_API_KEY}`,"Content-Type":"application/json"},
      body:JSON.stringify({
        model:OPENAI_IMAGE_MODEL,
        prompt:req.body?.prompt || "",
        size:req.body?.size || "1024x1024"
      })
    });
    const data=await response.json();
    if (!response.ok) throw new Error(data?.error?.message || "Image generation failed");
    const url=data?.data?.[0]?.url || null;
    const creation=saveCreation(user.id,{type:"image",prompt:req.body?.prompt || "",url,status:"completed"});
    res.json({url,creation,credits:user.credits});
  } catch(e) { res.status(e.status || 500).json({error:e.message}); }
});

app.post("/generate-video", async (req,res)=>{
  try {
    if (VIDEO_PROVIDER !== "replicate" || !REPLICATE_API_TOKEN)
      return res.status(503).json({error:"Video provider is not configured"});
    const user=getUser(req);
    const cost = Number(req.body?.seconds || 4) * 2;
    spendCredits(user, cost);

    // Keep this route intentionally isolated behind VIDEO_PROVIDER.
    // Replace this implementation with the provider's current async prediction API
    // and webhook/polling flow before production launch.
    const input={
      prompt:req.body?.prompt || "",
      seconds:String(req.body?.seconds || 4),
      aspect_ratio:req.body?.aspectRatio || "9:16"
    };
    const r=await fetch("https://api.replicate.com/v1/models/openai/sora-2/predictions",{
      method:"POST",
      headers:{
        "Authorization":`Bearer ${REPLICATE_API_TOKEN}`,
        "Content-Type":"application/json",
        "Prefer":"respond-async"
      },
      body:JSON.stringify({input})
    });
    const data=await r.json();
    if (!r.ok) throw new Error(data?.detail || data?.error || "Video provider failed");
    const jobId=data.id;
    jobs.set(jobId,{id:jobId,userId:user.id,status:data.status,provider:"replicate"});
    const creation=saveCreation(user.id,{type:"video",prompt:input.prompt,status:"processing",jobId});
    res.json({jobId,creation,credits:user.credits});
  } catch(e) { res.status(e.status || 500).json({error:e.message}); }
});

app.get("/video-jobs/:id", async (req,res)=>{
  try {
    const job=jobs.get(req.params.id);
    if (!job) return res.status(404).json({error:"Job not found"});
    if (job.provider!=="replicate") return res.status(400).json({error:"Unknown provider"});
    const r=await fetch(`https://api.replicate.com/v1/predictions/${job.id}`,{
      headers:{"Authorization":`Bearer ${REPLICATE_API_TOKEN}`}
    });
    const data=await r.json();
    if (!r.ok) throw new Error(data?.detail || "Could not check job");
    job.status=data.status;
    if (data.status==="succeeded") job.output=data.output;
    if (["failed","canceled"].includes(data.status)) job.error=data.error || "Generation failed";
    res.json(job);
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.listen(PORT,()=>console.log(`Wisdom AI Studio backend listening on ${PORT}`));

import 'package:flutter/material.dart';

class AccountScreen extends StatelessWidget {
  final int credits;
  const AccountScreen({super.key, required this.credits});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('My Account')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
        const Text('Wisdom AI Studio',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
        const SizedBox(height:18),
        Card(child:Padding(
          padding:const EdgeInsets.all(20),
          child:Row(children:[
            const Icon(Icons.bolt,size:32),
            const SizedBox(width:12),
            Text('$credits credits',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w600)),
          ])
        )),
        const SizedBox(height:12),
        const Text('Credits are managed by the server. Connect this screen to your payment/subscription provider before production.')
      ]),
    ),
  );
}

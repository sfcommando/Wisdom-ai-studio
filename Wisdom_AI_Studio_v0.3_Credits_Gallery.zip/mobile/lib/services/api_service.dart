import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl;
  final String userId;
  ApiService({required this.baseUrl, this.userId='demo-user'});

  Map<String,String> get _headers => {
    'Content-Type':'application/json',
    'x-user-id':userId,
  };

  Future<Map<String,dynamic>> me() async {
    final r=await http.get(Uri.parse('$baseUrl/me'),headers:_headers);
    return jsonDecode(r.body);
  }

  Future<List<dynamic>> creations() async {
    final r=await http.get(Uri.parse('$baseUrl/creations'),headers:_headers);
    if(r.statusCode>=400) throw Exception(jsonDecode(r.body)['error'] ?? 'Failed');
    return jsonDecode(r.body) as List<dynamic>;
  }

  Future<Map<String,dynamic>> chat(String message) async {
    final r=await http.post(Uri.parse('$baseUrl/chat'),headers:_headers,body:jsonEncode({'message':message}));
    final body=jsonDecode(r.body);
    if(r.statusCode>=400) throw Exception(body['error'] ?? 'Chat failed');
    return body;
  }

  Future<Map<String,dynamic>> image(String prompt) async {
    final r=await http.post(Uri.parse('$baseUrl/generate-image'),headers:_headers,body:jsonEncode({'prompt':prompt}));
    final body=jsonDecode(r.body);
    if(r.statusCode>=400) throw Exception(body['error'] ?? 'Image generation failed');
    return body;
  }

  Future<Map<String,dynamic>> video({required String prompt,int seconds=4,String aspectRatio='9:16'}) async {
    final r=await http.post(Uri.parse('$baseUrl/generate-video'),headers:_headers,body:jsonEncode({
      'prompt':prompt,'seconds':seconds,'aspectRatio':aspectRatio
    }));
    final body=jsonDecode(r.body);
    if(r.statusCode>=400) throw Exception(body['error'] ?? 'Video generation failed');
    return body;
  }

  Future<Map<String,dynamic>> videoJob(String id) async {
    final r=await http.get(Uri.parse('$baseUrl/video-jobs/$id'),headers:_headers);
    final body=jsonDecode(r.body);
    if(r.statusCode>=400) throw Exception(body['error'] ?? 'Job check failed');
    return body;
  }
}

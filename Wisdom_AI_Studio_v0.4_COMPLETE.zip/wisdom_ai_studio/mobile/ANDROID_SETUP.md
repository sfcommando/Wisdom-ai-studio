# Android setup

1. Install Flutter and Android Studio.
2. Create/open a Flutter Android project and place this `lib/`, `assets/`, and `pubspec.yaml` inside it.
3. Ensure `android/app/src/main/AndroidManifest.xml` includes:
   `<uses-permission android:name="android.permission.INTERNET"/>`
4. Run `flutter pub get`.
5. Start the backend with `npm install && npm start`.
6. Emulator:
   `flutter run --dart-define=BACKEND_URL=http://10.0.2.2:3000`
7. Physical phone:
   use your computer's LAN IP, e.g.
   `flutter run --dart-define=BACKEND_URL=http://192.168.1.20:3000`

Use HTTPS and a production backend before release.

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

const backendUrl = String.fromEnvironment(
  'BACKEND_URL',
  defaultValue: 'http://10.0.2.2:3000',
);

void main() => runApp(const WisdomAIStudio());

class WisdomAIStudio extends StatelessWidget {
  const WisdomAIStudio({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Wisdom AI Studio',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF08090D),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF8B5CF6),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Widget feature(BuildContext context, IconData icon, String title,
      String subtitle, VoidCallback action) {
    return Expanded(
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: action,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 24,
                  child: Icon(icon),
                ),
                const SizedBox(height: 14),
                Text(title,
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 5),
                Text(subtitle,
                    style: TextStyle(color: Colors.grey[400], fontSize: 12)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void coming(BuildContext context, String name) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PlaceholderFeature(title: name)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Wisdom AI Studio',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            onPressed: () => coming(context, 'My Creations'),
            icon: const Icon(Icons.folder_copy_outlined),
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF24113F), Color(0xFF101522)],
              ),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Create anything.',
                    style: TextStyle(
                        fontSize: 30, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text(
                  'Chat, create images, and turn your ideas or photos into cinematic videos.',
                  style: TextStyle(fontSize: 15, height: 1.4),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              feature(context, Icons.movie_filter_outlined, 'Video',
                  'Text or photo → video', () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const VideoCreator()));
              }),
              const SizedBox(width: 12),
              feature(context, Icons.auto_awesome_outlined, 'Image',
                  'Create images with AI', () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const ImageCreator()));
              }),
            ],
          ),
          Row(
            children: [
              feature(context, Icons.chat_bubble_outline, 'AI Chat',
                  'Ask, write, learn', () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const ChatScreen()));
              }),
              const SizedBox(width: 12),
              feature(context, Icons.folder_outlined, 'Creations',
                  'Your generated work', () {
                coming(context, 'My Creations');
              }),
            ],
          ),
          const SizedBox(height: 18),
          const Text('Quick ideas',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          for (final idea in [
            'Create a cinematic portrait video from my photo',
            'Write a professional message for me',
            'Generate a futuristic African city at night',
          ])
            Card(
              child: ListTile(
                leading: const Icon(Icons.lightbulb_outline),
                title: Text(idea),
                trailing: const Icon(Icons.arrow_forward_ios, size: 15),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const VideoCreator(),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class VideoCreator extends StatefulWidget {
  const VideoCreator({super.key});
  @override
  State<VideoCreator> createState() => _VideoCreatorState();
}

class _VideoCreatorState extends State<VideoCreator> {
  final prompt = TextEditingController();
  final picker = ImagePicker();
  XFile? image;
  bool loading = false;
  String status = '';
  String? videoUrl;
  String seconds = '4';
  String ratio = 'portrait';

  Future<void> pickImage() async {
    final x = await picker.pickImage(source: ImageSource.gallery);
    if (x != null) setState(() => image = x);
  }

  Future<void> generate() async {
    if (prompt.text.trim().isEmpty) {
      setState(() => status = 'Enter a prompt first.');
      return;
    }
    setState(() {
      loading = true;
      status = 'Generating your video...';
      videoUrl = null;
    });
    try {
      final req = http.MultipartRequest(
        'POST',
        Uri.parse('$backendUrl/generate-video'),
      );
      req.fields['prompt'] = prompt.text.trim();
      req.fields['seconds'] = seconds;
      req.fields['aspect_ratio'] = ratio;
      if (image != null) {
        req.files.add(await http.MultipartFile.fromPath('image', image!.path));
      }
      final response = await http.Response.fromStream(await req.send());
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception(response.body);
      }
      final data = jsonDecode(response.body);
      setState(() {
        videoUrl = data['videoUrl'];
        status = 'Video ready.';
      });
    } catch (e) {
      setState(() => status = 'Error: $e');
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    prompt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Video')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: prompt,
            maxLines: 5,
            decoration: InputDecoration(
              labelText: 'Describe your video',
              hintText: 'A cinematic slow camera push toward the subject...',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18)),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: seconds,
                  decoration: const InputDecoration(labelText: 'Duration'),
                  items: ['4', '8', '12']
                      .map((v) => DropdownMenuItem(value: v, child: Text('$v sec')))
                      .toList(),
                  onChanged: loading ? null : (v) => setState(() => seconds = v!),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: ratio,
                  decoration: const InputDecoration(labelText: 'Format'),
                  items: const [
                    DropdownMenuItem(value: 'portrait', child: Text('Portrait')),
                    DropdownMenuItem(value: 'landscape', child: Text('Landscape')),
                  ],
                  onChanged: loading ? null : (v) => setState(() => ratio = v!),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: loading ? null : pickImage,
            icon: const Icon(Icons.add_photo_alternate_outlined),
            label: Text(image == null ? 'Add photo reference' : 'Change photo'),
          ),
          if (image != null) ...[
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: Image.file(File(image!.path), height: 280, fit: BoxFit.cover),
            ),
          ],
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: loading ? null : generate,
            icon: loading
                ? const SizedBox(
                    height: 18, width: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.auto_awesome),
            label: Text(loading ? 'Creating...' : 'Generate Video'),
          ),
          if (status.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(status),
          ],
          if (videoUrl != null) ...[
            const SizedBox(height: 18),
            VideoPreview(url: videoUrl!),
          ],
        ],
      ),
    );
  }
}

class VideoPreview extends StatefulWidget {
  final String url;
  const VideoPreview({super.key, required this.url});
  @override
  State<VideoPreview> createState() => _VideoPreviewState();
}

class _VideoPreviewState extends State<VideoPreview> {
  late final VideoPlayerController controller;

  @override
  void initState() {
    super.initState();
    controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) {
        if (mounted) setState(() {});
      });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!controller.value.isInitialized) {
      return const Center(child: CircularProgressIndicator());
    }
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: AspectRatio(
            aspectRatio: controller.value.aspectRatio,
            child: VideoPlayer(controller),
          ),
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: () => setState(() {
            controller.value.isPlaying
                ? controller.pause()
                : controller.play();
          }),
          icon: Icon(controller.value.isPlaying
              ? Icons.pause
              : Icons.play_arrow),
          label: Text(controller.value.isPlaying ? 'Pause' : 'Play'),
        ),
      ],
    );
  }
}

class ImageCreator extends StatefulWidget {
  const ImageCreator({super.key});
  @override
  State<ImageCreator> createState() => _ImageCreatorState();
}

class _ImageCreatorState extends State<ImageCreator> {
  final prompt = TextEditingController();
  bool loading = false;
  Uint8List? bytes;
  String status = '';

  Future<void> generate() async {
    if (prompt.text.trim().isEmpty) return;
    setState(() {
      loading = true;
      status = 'Creating image...';
      bytes = null;
    });
    try {
      final r = await http.post(
        Uri.parse('$backendUrl/generate-image'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'prompt': prompt.text.trim()}),
      );
      if (r.statusCode < 200 || r.statusCode >= 300) {
        throw Exception(r.body);
      }
      final data = jsonDecode(r.body);
      setState(() {
        bytes = base64Decode(data['imageBase64']);
        status = 'Image ready.';
      });
    } catch (e) {
      setState(() => status = 'Error: $e');
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    prompt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Create Image')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextField(
              controller: prompt,
              maxLines: 5,
              decoration: InputDecoration(
                labelText: 'Image prompt',
                hintText: 'A cinematic portrait in a futuristic African city...',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(18)),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: loading ? null : generate,
              icon: loading
                  ? const SizedBox(
                      height: 18, width: 18,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.auto_awesome),
              label: Text(loading ? 'Creating...' : 'Generate Image'),
            ),
            const SizedBox(height: 12),
            Text(status),
            if (bytes != null) ...[
              const SizedBox(height: 18),
              ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Image.memory(bytes!, fit: BoxFit.cover),
              ),
            ],
          ],
        ),
      );
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final input = TextEditingController();
  final messages = <Map<String, String>>[];
  bool loading = false;

  Future<void> send() async {
    final text = input.text.trim();
    if (text.isEmpty || loading) return;
    setState(() {
      messages.add({'role': 'user', 'text': text});
      input.clear();
      loading = true;
    });
    try {
      final r = await http.post(
        Uri.parse('$backendUrl/chat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'message': text}),
      );
      if (r.statusCode < 200 || r.statusCode >= 300) {
        throw Exception(r.body);
      }
      final data = jsonDecode(r.body);
      setState(() => messages.add({
            'role': 'assistant',
            'text': data['text'] ?? 'No response.'
          }));
    } catch (e) {
      setState(() => messages.add({'role': 'assistant', 'text': 'Error: $e'}));
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('AI Chat')),
        body: Column(
          children: [
            Expanded(
              child: messages.isEmpty
                  ? const Center(
                      child: Text('Ask Wisdom anything.',
                          style: TextStyle(fontSize: 18)))
                  : ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: messages.length,
                      itemBuilder: (_, i) {
                        final m = messages[i];
                        final user = m['role'] == 'user';
                        return Align(
                          alignment: user
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                          child: Container(
                            margin: const EdgeInsets.symmetric(vertical: 5),
                            padding: const EdgeInsets.all(13),
                            constraints: const BoxConstraints(maxWidth: 330),
                            decoration: BoxDecoration(
                              color: user
                                  ? const Color(0xFF5B21B6)
                                  : const Color(0xFF181B24),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Text(m['text']!),
                          ),
                        );
                      },
                    ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: input,
                        minLines: 1,
                        maxLines: 4,
                        decoration: InputDecoration(
                          hintText: 'Message Wisdom...',
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20)),
                        ),
                        onSubmitted: (_) => send(),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filled(
                      onPressed: loading ? null : send,
                      icon: const Icon(Icons.send),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
}

class PlaceholderFeature extends StatelessWidget {
  final String title;
  const PlaceholderFeature({super.key, required this.title});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(30),
            child: Text(
              '$title is planned for the next build. The core AI creation system is already structured.',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18),
            ),
          ),
        ),
      );
}
